--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
ALTER TABLE ONLY public.ruang DROP CONSTRAINT ruang_pkey;
ALTER TABLE ONLY public.petugas DROP CONSTRAINT petugas_pkey;
ALTER TABLE ONLY public.peminjaman DROP CONSTRAINT peminjaman_pkey;
ALTER TABLE ONLY public.pegawai DROP CONSTRAINT pegawai_pkey;
ALTER TABLE ONLY public.jenis DROP CONSTRAINT jenis_pkey;
ALTER TABLE ONLY public.inventaris DROP CONSTRAINT inventaris_pkey;
ALTER TABLE ONLY public.detail_pinjam DROP CONSTRAINT detail_pinjam_pkey;
DROP TABLE public.tb_level;
DROP TABLE public.ruang;
DROP TABLE public.petugas;
DROP TABLE public.peminjaman;
DROP TABLE public.pegawai;
DROP TABLE public.jenis;
DROP TABLE public.inventaris;
DROP TABLE public.detail_pinjam;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: detail_pinjam; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detail_pinjam (
    id_detail_pinjam character varying(11) NOT NULL,
    id_inventaris character varying(11),
    jumlah integer
);


ALTER TABLE detail_pinjam OWNER TO postgres;

--
-- Name: inventaris; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE inventaris (
    id_inventaris character varying(11) NOT NULL,
    nama character varying(30),
    kondisi character varying(30),
    keterangan character varying(50),
    jumlah integer,
    id_jenis character varying(11),
    tanggal_register date,
    id_ruang character varying(11),
    kode_inventaris character varying(15),
    id_petugas character varying(11)
);


ALTER TABLE inventaris OWNER TO postgres;

--
-- Name: jenis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE jenis (
    id_jenis character varying(11) NOT NULL,
    nama_jenis character varying(30),
    kode_jenis character varying(15),
    keterangan character varying(50)
);


ALTER TABLE jenis OWNER TO postgres;

--
-- Name: pegawai; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pegawai (
    id_pegawai character varying(11) NOT NULL,
    nama_pegawai character varying(30),
    nip character varying(11),
    alamat text
);


ALTER TABLE pegawai OWNER TO postgres;

--
-- Name: peminjaman; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE peminjaman (
    id_peminjaman character varying(11) NOT NULL,
    tanggal_pinjam date,
    tanggal_kembali date,
    status_peminjaman character varying(20),
    id_pegawai character varying(11)
);


ALTER TABLE peminjaman OWNER TO postgres;

--
-- Name: petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE petugas (
    id_petugas character varying(11) NOT NULL,
    username character varying(30),
    password character varying(30),
    nama_petugas character varying(50),
    id_level character varying(20)
);


ALTER TABLE petugas OWNER TO postgres;

--
-- Name: ruang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE ruang (
    id_ruang character varying(11) NOT NULL,
    nama_ruang character varying(30),
    kode_ruang character varying(15),
    keterangan character varying(100)
);


ALTER TABLE ruang OWNER TO postgres;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level character varying(11) NOT NULL,
    nama_level character varying(30)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Data for Name: detail_pinjam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detail_pinjam (id_detail_pinjam, id_inventaris, jumlah) FROM stdin;
\.
COPY detail_pinjam (id_detail_pinjam, id_inventaris, jumlah) FROM '$$PATH$$/2839.dat';

--
-- Data for Name: inventaris; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM stdin;
\.
COPY inventaris (id_inventaris, nama, kondisi, keterangan, jumlah, id_jenis, tanggal_register, id_ruang, kode_inventaris, id_petugas) FROM '$$PATH$$/2834.dat';

--
-- Data for Name: jenis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM stdin;
\.
COPY jenis (id_jenis, nama_jenis, kode_jenis, keterangan) FROM '$$PATH$$/2835.dat';

--
-- Data for Name: pegawai; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pegawai (id_pegawai, nama_pegawai, nip, alamat) FROM stdin;
\.
COPY pegawai (id_pegawai, nama_pegawai, nip, alamat) FROM '$$PATH$$/2841.dat';

--
-- Data for Name: peminjaman; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY peminjaman (id_peminjaman, tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai) FROM stdin;
\.
COPY peminjaman (id_peminjaman, tanggal_pinjam, tanggal_kembali, status_peminjaman, id_pegawai) FROM '$$PATH$$/2840.dat';

--
-- Data for Name: petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY petugas (id_petugas, username, password, nama_petugas, id_level) FROM stdin;
\.
COPY petugas (id_petugas, username, password, nama_petugas, id_level) FROM '$$PATH$$/2837.dat';

--
-- Data for Name: ruang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM stdin;
\.
COPY ruang (id_ruang, nama_ruang, kode_ruang, keterangan) FROM '$$PATH$$/2836.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2838.dat';

--
-- Name: detail_pinjam detail_pinjam_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY detail_pinjam
    ADD CONSTRAINT detail_pinjam_pkey PRIMARY KEY (id_detail_pinjam);


--
-- Name: inventaris inventaris_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inventaris
    ADD CONSTRAINT inventaris_pkey PRIMARY KEY (id_inventaris);


--
-- Name: jenis jenis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY jenis
    ADD CONSTRAINT jenis_pkey PRIMARY KEY (id_jenis);


--
-- Name: pegawai pegawai_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pegawai
    ADD CONSTRAINT pegawai_pkey PRIMARY KEY (id_pegawai);


--
-- Name: peminjaman peminjaman_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY peminjaman
    ADD CONSTRAINT peminjaman_pkey PRIMARY KEY (id_peminjaman);


--
-- Name: petugas petugas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY petugas
    ADD CONSTRAINT petugas_pkey PRIMARY KEY (id_petugas);


--
-- Name: ruang ruang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY ruang
    ADD CONSTRAINT ruang_pkey PRIMARY KEY (id_ruang);


--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- PostgreSQL database dump complete
--

